/**
 * @file
 * Global utilities.
 *
 */
(function ($, Drupal) {

  'use strict';

  Drupal.behaviors.daniel_drupal = {
    attach: function (context, settings) {

    }
  };

})(jQuery, Drupal);
;
